HeatUp PWA Prototype

How to deploy (quick):
1) Create a private repo on GitHub named HeatUpApp.
2) Upload all files from this package (or drag & drop the ZIP contents).
3) Create a new site on Netlify and connect to the repo (or drag & drop the folder into Netlify drop).
4) Ensure the site is served via HTTPS. On phone, open the URL and 'Add to Home Screen'.

Notes:
- Notifications require HTTPS and user permission.
- This is a demo prototype. Integrate a backend (Firebase) for real users, chat, and push notifications.
